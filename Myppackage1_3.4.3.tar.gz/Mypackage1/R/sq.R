#' Square a number
#'
#' Take any numeric value
#' @param A numeric value to be squared
#' @return The square of the input
#' @export

square <- function(x){
  return(x^2)
}
